from modelx.serialize.jsonvalues import *

_name = "BasicTerm_ME"

_allow_none = False

_spaces = [
    "Projection"
]

