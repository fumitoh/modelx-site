from modelx.serialize.jsonvalues import *

_name = "newlife"

_allow_none = False

_spaces = [
    "Input",
    "LifeTable",
    "Economic",
    "BaseProj",
    "PV",
    "Projection"
]

